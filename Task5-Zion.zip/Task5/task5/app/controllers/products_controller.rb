class ProductsController < ApplicationController
  def products
  end
end
