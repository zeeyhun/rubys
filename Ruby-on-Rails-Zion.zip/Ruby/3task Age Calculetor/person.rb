# frozen_string_literal: true

# Description/Explanation of Person class
class Person
  require 'date'

  attr_accessor :name, :surname, :age

  def age_in_years(day, month, year)
    birthdate = Time.new(year, month, day)
    avg_seconds_in_year = 315_576_00
    seconds = (Time.now - birthdate).to_i
    (seconds / avg_seconds_in_year)
  end

  def initialize(name_a, surname_b)
    @name = name_a
    @surname = surname_b
  end

  def person_info
    "Name: #{name}\nSurname: #{surname}\nAge: #{age_in_years(7, 11, 1999)}"
  end
end
