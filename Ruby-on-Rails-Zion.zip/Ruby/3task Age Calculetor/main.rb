# frozen_string_literal: true

require_relative 'person'
pr1 = Person.new('Abdo', 'Ahmed')

print pr1.person_info
