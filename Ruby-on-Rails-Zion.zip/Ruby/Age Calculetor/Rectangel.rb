def RectangleSize (length,width)

result = length * width
result
end

def Rectangleperimeter (length,width)

result = 2* (length + width)
result
end
def Rectanglediagonal (length,width)

result = Math.sqrt((width * width)+(length * length))
result
end

def Rectanglediagonalscrossingpointcoordinate (length,width)
    x0=0
    y0=0
    x1=0
    y1=0
    x2=0
    y2=0
    x3=0
    y3=0
    points = {}

    x1 = (x0 + length)
    y1 = y0

    x2= x0 - width
    y2= y0

    x3= x0  + length
    y3= y0 - width
    points[0] = (x1 - x2) / 2
    points[1] = (y1 - y2) / 2
    points
end

puts "Rectangle size: #{ RectangleSize(5,10)}"  

puts "Rectangle perimeter: #{ Rectangleperimeter(5,10)}"  

puts "Rectangle diagonal: #{ Rectanglediagonal(5,10)}"  

puts "Rectangle diagonal: #{ Rectanglediagonalscrossingpointcoordinate(10,15)}"  