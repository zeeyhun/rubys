require 'date'

def age_to_years(day, month, year)   
  birthdate = Time.new(year, month, day)
  avg_seconds_in_year = 31557600
  seconds = (Time.now- birthdate).to_i
  years = seconds/avg_seconds_in_year
  years

end
print"first name: "
fname = gets
print"last name: "
lname = gets
print"birthdate in (day/month/yers)"
day = gets
month = gets
year = gets
puts"Full name #{fname + lname}"
puts"Age: "
 puts  age_to_years(day,month,year)