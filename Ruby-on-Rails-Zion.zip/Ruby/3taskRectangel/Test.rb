require_relative "rectangle"
require 'test/unit'

class MyTest < Test::Unit::TestCase


  def test_fail
    assert_equal(8, Rectangle.new(2,4).rectangle_size)
    assert_equal(20, Rectangle.new(5,5).rectangle_perimeter)
    assert_equal(11.180339887498949, Rectangle.new(5,10).rectangle_diagonal)
    assert_equal([12, 0], Rectangle.new(10,15).diagonals_crossing_point_coordinate)
  end
end