# frozen_string_literal: true

# Description/Explanation of Person class

class Rectangle
    attr_accessor :length, :width

  def initialize(length, width)
    @length = length
    @width = width
  end 

  def rectangle_size
    length * width
  end

  def rectangle_perimeter
    2 * (length + width)
  end

  def rectangle_diagonal
    Math.sqrt((width * width) + (length * length))
  end

  def diagonals_crossing_point_coordinate
    [
        diagonals_crossing_point_coordinate_x, 
        diagonals_crossing_point_coordinate_y
    ]
  end

  def diagonals_crossing_point_coordinate_x
    x0 = 0
    x1 = (x0 + length)
    x2 = x0 - width
    (x1 - x2) / 2
  end

  def diagonals_crossing_point_coordinate_y
    y0 = 0
    y1 = y0
    y2 = y0
    (y1 - y2) / 2
  end
end
