
class PersonClassExample
   
    @@count = 0
  
    attr_reader :name, :age
 
    attr_writer :name, :age
  

    attr_accessor :name, :age
  
 
    def initialize(first_par, second_par = -1)
      @@count += 1
  
      @name = first_par.to_s
      @age = corrected_age(second_par.to_i)
    end
  
    def person_info
      puts "Name: #{@name}; Age: #{@age}; Class: #{class_name}"
    end
  
    private
  
    def corrected_age(value) 
      value < 0 ? 0 : value
    end
  
    protected
  
    def class_name
      self.class.to_s
    end
  
    public
  
    def self.person_count
      puts "Class (PersonClassExample) Objects Instances Defined - #{@@count}"
    end
  end
  
  puts 'PersonClassExample.person_count'
  print('  '); PersonClassExample.person_count
  puts '00000'; puts
  
  john = PersonClassExample.new('John')
  
  puts 'PersonClassExample.person_count'
  print('  '); PersonClassExample.person_count
  puts 'john.person_info'
  print('  '); john.person_info
  puts '11111'; puts
  
  rose = PersonClassExample.new('Rose', 50)
  
  puts 'PersonClassExample.person_count'
  print('  '); PersonClassExample.person_count
  puts 'rose.person_info'
  print('  '); rose.person_info
  puts '22222'; puts
  
  # Class which inherits another Class
  class Person < PersonClassExample
    def sub_info
      puts "Name: #{@name}; Age: #{@age}; Class Name: #{class_name}"
    end
  end
  
  somebody = Person.new("Body")
  puts 'somebody.sub_info'
  print('  '); somebody.sub_info
  puts '33333'; puts
  
  

  module Helper
   
    def some_text
      "some_text"
    end
  
    
    def self.some_number
      10
    end
  end
  
  puts 'puts Helper.some_number'
  print('  '); puts Helper.some_number
  puts '44444'; puts
  
  class MainClass
    include Helper
  end
  
  puts 'puts MainClass.new.some_text'
  print('  '); puts MainClass.new.some_text
  puts '55555'; puts
  
  class SecondaryClass
    extend Helper
  end
  
  puts 'puts SecondaryClass.some_text'
  print('  '); puts SecondaryClass.some_text
  puts '66666'; puts
  
  
  module Work
    class Timetable
      def self.tomorrow
        'Tomorrow there will be now work'
      end
    end
  end
  puts 'puts Work::Timetable.tomorrow'
  print('  '); puts Work::Timetable.tomorrow
  puts '77777'; puts
  
  module College
    class Timetable
      def self.tomorrow
        'Tomorrow there will be some lectures'
      end
    end
  end
  
  puts 'puts College::Timetable.tomorrow'
  print('  '); puts College::Timetable.tomorrow
  puts '88888'; puts