# frozen_string_literal: true

require_relative 'rectangle'
pr1 = Rectangle.new(5, 5)
pr2 = Rectangle.new(5, 5)
pr3 = Rectangle.new(5, 10)
pr4 = Rectangle.new(10, 15)

puts "Rectangle size: #{pr1.get_rectangle_size}"

puts "Rectangle perimeter: #{pr2.get_rectangle_perimeter}"

puts "Rectangle diagonal: #{pr3.get_rectangle_diagonal}"

puts "Rectangle diagonal: #{pr4.diagonals_crossing_point_coordinate}"
