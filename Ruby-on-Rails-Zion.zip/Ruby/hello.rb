puts "labas"

def find_length(input_array)
    length = []
  input_array.each{ |a| length << a.length}
  length
  puts length
end

find_length ['Ruby','Rails','C42']
###########calculator ###########

puts "calculator"

class Calculate
    def addition(a, b)
    
      @a = a
      @b = b
      @sum = @a + @b
      puts @sum
      end
  
    def subtraction(a, b)
    
      @a = a
      @b = b
      @result = @a - @b
      puts @result
    end
  end
  
  object = Calculate. new
  object.addition(5,6)
  object.subtraction(2,1)

  ###########Select random elements from an array ###########

  puts " random elements from an array";

def select_rand(array)
  # your code here
 array = [1,9,5,2,4,9,5,8,7,9,0,8,2,7,5,8,0,2,9]

   puts (array.sample)
end

select_rand []