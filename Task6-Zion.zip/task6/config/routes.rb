Rails.application.routes.draw do
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html



  get 'about' => 'pages#about'
  get 'products' => 'products#productList'
  get 'search' => 'products#search'
  delete '/delete/:id' => 'products#delete'

  resources :products

  root 'index#HomeScreen'

end
