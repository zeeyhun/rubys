class IndexController < ApplicationController
  def index

  end
end
