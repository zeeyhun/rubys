class ProductsController < ApplicationController
  def productList
    @product = Product.all
  end


  def show
    @product = Product.find(params[:id])

  end

  def new
    @product = Product.new
  end
  def create
    #render plain: params[:Product].inspect
    @product = Product.new(product_params)

    if(@product.save)
        redirect_to @product
    else
      render 'new'
    end
  end

  def edit
    @product = Product.find(params[:id])
  end

  def update
    @product = Product.find(params[:id])

    if(@product.update(product_params))
      redirect_to @product
    else
      render 'edit'
    end
  end

  def delete
    @product = Product.find(params[:id])
    @product.destroy
    redirect_to products_path

  end

  def search
    @result = Product.where("title LIKE ?", "%" +params[:q]+ "%")
  end



  private def product_params
    params.require(:product).permit(:title,:price,:imageURL,:discription)
  end
end
