class Product < ApplicationRecord
  # validates :title, presence: true,
  #           length: {minimum:5}
  # validates :price, presence: true
  # validates :imageURL, presence: true
  # validates :discription, presence: true
end
